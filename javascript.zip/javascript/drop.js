function removecolor()
{
var x=document.getElementById("colorSelect");
x.remove(x.selectedIndex);
}