function is_alphaNumeric(str)
{
 regexp = /^[A-Za-z0-9]+$/;
  
        if (regexp.test(str))
          {
            return true;
          }
        else
          {
            return false;
          }
}

document.write(is_alphaNumeric("37828sad"));

document.write(is_alphaNumeric("3243#$sew"));

